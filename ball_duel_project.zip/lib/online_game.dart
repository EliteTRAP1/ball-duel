
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class OnlineGameScreen extends StatefulWidget {
  final String roomCode;
  final String player;

  const OnlineGameScreen({super.key, required this.roomCode, required this.player});

  @override
  State<OnlineGameScreen> createState() => _OnlineGameScreenState();
}

class _OnlineGameScreenState extends State<OnlineGameScreen> {
  final database = FirebaseDatabase.instance.ref();
  double myX = 100;
  double otherX = 200;
  double ballX = 150;
  double ballY = 0;
  int score = 0;
  int timeLeft = 30;
  bool isGameOver = false;
  late Timer localTimer;

  String get opponent => widget.player == 'player1' ? 'player2' : 'player1';

  @override
  void initState() {
    super.initState();

    // تحديث موقعي
    database.child('games/\${widget.roomCode}/\${widget.player}').onValue.listen((event) {
      final data = event.snapshot.value as Map?;
      if (data != null && data['x'] != null) {
        setState(() {
          myX = double.tryParse(data['x'].toString()) ?? myX;
        });
      }
    });

    // تحديث موقع الخصم
    database.child('games/\${widget.roomCode}/\$opponent').onValue.listen((event) {
      final data = event.snapshot.value as Map?;
      if (data != null && data['x'] != null) {
        setState(() {
          otherX = double.tryParse(data['x'].toString()) ?? otherX;
        });
      }
    });

    // مراقبة الكرة
    database.child('games/\${widget.roomCode}/ball').onValue.listen((event) {
      final data = event.snapshot.value as Map?;
      if (data != null) {
        setState(() {
          ballX = double.tryParse(data['x'].toString()) ?? ballX;
          ballY = double.tryParse(data['y'].toString()) ?? ballY;
        });
      }
    });

    // مراقبة الوقت
    database.child('games/\${widget.roomCode}/time').onValue.listen((event) {
      final value = event.snapshot.value;
      if (value != null) {
        setState(() {
          timeLeft = int.tryParse(value.toString()) ?? timeLeft;
        });
      }
    });

    // مراقبة الحالة
    database.child('games/\${widget.roomCode}/status').onValue.listen((event) {
      if (event.snapshot.value == 'gameover') {
        setState(() {
          isGameOver = true;
        });
      }
    });

    // Player 1 يتحكم في الكرة والمؤقت
    if (widget.player == 'player1') {
      startBallAndTimerLoop();
    }
  }

  void startBallAndTimerLoop() {
    double speed = 150;

    localTimer = Timer.periodic(const Duration(milliseconds: 50), (timer) async {
      if (isGameOver || timeLeft <= 0) {
        await database.child('games/\${widget.roomCode}/status').set('gameover');
        timer.cancel();
        return;
      }

      // حركة الكرة للأسفل
      ballY += speed * 0.05;

      // إذا وصلت الكرة للأسفل
      if (ballY > 500) {
        if ((ballX - myX).abs() < 80) {
          score++;
        } else {
          await database.child('games/\${widget.roomCode}/status').set('gameover');
          timer.cancel();
          return;
        }
        // إعادة الكرة
        ballX = (100 + (200 * (score % 3))).toDouble();
        ballY = 0;
        await database.child('games/\${widget.roomCode}/score').set(score);
      }

      // إرسال موقع الكرة
      await database.child('games/\${widget.roomCode}/ball').set({
        'x': ballX,
        'y': ballY,
      });

      // تقليل الوقت كل ثانية
      if (timer.tick % 20 == 0) {
        timeLeft--;
        await database.child('games/\${widget.roomCode}/time').set(timeLeft);
      }
    });
  }

  void move(double dx) {
    myX += dx;
    database.child('games/\${widget.roomCode}/\${widget.player}').set({'x': myX});
  }

  @override
  void dispose() {
    if (widget.player == 'player1') localTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Room: \${widget.roomCode}')),
      body: Stack(
        children: [
          Positioned(
            left: myX,
            bottom: 50,
            child: Container(width: 80, height: 20, color: Colors.blue),
          ),
          Positioned(
            left: otherX,
            top: 50,
            child: Container(width: 80, height: 20, color: Colors.red),
          ),
          Positioned(
            left: ballX,
            top: ballY,
            child: Container(width: 30, height: 30, decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle)),
          ),
          Positioned(
            top: 10,
            left: 10,
            child: Text('Time: \$timeLeft', style: const TextStyle(fontSize: 20)),
          ),
          Positioned(
            top: 10,
            right: 10,
            child: Text('Score: \$score', style: const TextStyle(fontSize: 20)),
          ),
          if (isGameOver)
            Center(
              child: Container(
                color: Colors.black54,
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Game Over', style: TextStyle(fontSize: 32)),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text('Exit'),
                    ),
                  ],
                ),
              ),
            ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: () => move(-10), icon: const Icon(Icons.arrow_left)),
                IconButton(onPressed: () => move(10), icon: const Icon(Icons.arrow_right)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
